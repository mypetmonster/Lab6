﻿Option Strict On
Imports System.IO
Public Class frmMain

    ' Subroutine for opening files
    Private Sub mnuOpen_Click(sender As Object, e As EventArgs) Handles mnuOpen.Click

        Dim openFile As New OpenFileDialog()

        Dim newForm As New TextForm

        newForm.MdiParent = Me

        openFile.CheckFileExists = True
        openFile.DefaultExt = "txt"
        openFile.InitialDirectory = "C:\"
        openFile.Multiselect = False

        If openFile.ShowDialog = DialogResult.OK Then
            Try
                Dim reader As New StreamReader(openFile.FileName)
                newForm.tbText.Text = reader.ReadToEnd
                newForm.Text = openFile.FileName
                reader.Close()
                newForm.Show()
            Catch ex As Exception
                Throw New ApplicationException(ex.ToString)
            End Try
        End If

    End Sub

    ' Subroutine for Save
    Private Sub mnuSave_Click(sender As Object, e As EventArgs) Handles mnuSave.Click
        Dim saveFile As New SaveFileDialog()
        Dim activeForm As TextForm = DirectCast(Me.ActiveMdiChild, TextForm)
        Dim writer As StreamWriter

        saveFile.Filter = "TXT Files (*.txt*)|*.txt"

        If activeForm.Text = "Text" Then
            saveFile.ShowDialog()
            My.Computer.FileSystem.WriteAllText(saveFile.FileName, activeForm.tbText.Text, False)
            activeForm.Text = saveFile.FileName
        Else
            writer = New StreamWriter(activeForm.Text)
            writer.Write(activeForm.tbText.Text)
            writer.Close()
        End If
    End Sub

    ' Subroutine for Save As
    Private Sub mnuSaveAs_Click(sender As Object, e As EventArgs) Handles mnuSaveAs.Click
        Dim saveFile As New SaveFileDialog()
        Dim activeForm As TextForm = DirectCast(Me.ActiveMdiChild, TextForm)

        saveFile.Filter = "TXT Files (*.txt*)|*.txt"

        saveFile.ShowDialog()
        My.Computer.FileSystem.WriteAllText(saveFile.FileName, activeForm.tbText.Text, False)
        activeForm.Text = saveFile.FileName
    End Sub

    ' Subroutine for cutting text
    Private Sub mnuCut_Click(sender As Object, e As EventArgs) Handles mnuCut.Click
        Dim activeForm As TextForm = DirectCast(Me.ActiveMdiChild, TextForm)
        activeForm.tbText.Cut()
    End Sub

    ' Subroutine for copying text
    Private Sub mnuCopy_Click(sender As Object, e As EventArgs) Handles mnuCopy.Click
        Dim activeForm As TextForm = DirectCast(Me.ActiveMdiChild, TextForm)
        activeForm.tbText.Copy()
    End Sub

    ' Subroutine for pasting text
    Private Sub mnuPaste_Click(sender As Object, e As EventArgs) Handles mnuPaste.Click
        Dim activeForm As TextForm = DirectCast(Me.ActiveMdiChild, TextForm)
        activeForm.tbText.Paste()
    End Sub

    ' Subroutine for exiting program
    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        Application.Exit()
    End Sub

    ' Subroutine for creating new form
    Private Sub mnuNew_Click(sender As Object, e As EventArgs) Handles mnuNew.Click
        Dim newForm As New TextForm
        newForm.MdiParent = Me
        newForm.Show()
    End Sub

    ' Subroutine for opening Average Units
    Private Sub AverageUnitsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuAverageUnits.Click
        Dim newForm As New AverageUnits
        newForm.MdiParent = Me
        newForm.Show()
    End Sub

    ' Subroutine for Close current form
    Private Sub mnuClose_Click(sender As Object, e As EventArgs) Handles mnuClose.Click
        Dim activeForm As TextForm = DirectCast(Me.ActiveMdiChild, TextForm)

        Try
            activeForm.Close()
        Catch ex As Exception
            MessageBox.Show("No file to close.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Subroutine for Cascade layout
    Private Sub mnuCascade_Click(sender As Object, e As EventArgs) Handles mnuCascade.Click
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    ' Subroutine for Vertical layout
    Private Sub mnuTileVertical_Click(sender As Object, e As EventArgs) Handles mnuTileVertical.Click
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

    ' Subroutine for Horizontal layout
    Private Sub mnuTileHorizontal_Click(sender As Object, e As EventArgs) Handles mnuTileHorizontal.Click
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    ' Subroutine for About
    Private Sub mnuAbout_Click(sender As Object, e As EventArgs) Handles mnuAbout.Click
        MessageBox.Show("Don't steal my program, bubs. I worked very hard on it.", "Warning Imbeciles", MessageBoxButtons.OK)
    End Sub
End Class