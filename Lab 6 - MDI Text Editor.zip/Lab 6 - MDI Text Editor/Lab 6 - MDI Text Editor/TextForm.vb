﻿Public Class TextForm
    Friend filePath As String = ""
End Class