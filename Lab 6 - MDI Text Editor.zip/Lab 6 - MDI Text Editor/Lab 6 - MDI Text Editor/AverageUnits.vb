﻿Option Strict On
Public Class AverageUnits

    'Variables
    Dim currentEmployee As Integer = 1
    Dim currentDay As Integer = 1
    Dim unitsShipped(2, 6) As Integer

    Dim employee1Average As Double = 0
    Dim employee2Average As Double = 0
    Dim employee3Average As Double = 0
    Dim totalAverage As Double = 0

    'Constants
    Const min As Integer = 0
    Const max As Integer = 1000

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        Dim userInput As Integer = 0

        'Empty input is not valid
        If (tbInput.Text = "") Then

            MessageBox.Show("Nothing entered. Please enter a whole number between 0 and 1000, inclusive.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Non-numeric input is not valid
        ElseIf (IsNumeric(tbInput.Text) = False) Then

            MessageBox.Show("Not numeric. Please enter a whole number between 0 and 1000, inclusive.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            tbInput.Text = ""

        Else

            userInput = CInt(tbInput.Text)

            'Decimals are not valid
            If ((userInput.ToString = tbInput.Text) = False) Then

                MessageBox.Show("Please no decimals, Austin. Please enter a whole number between 0 and 1000, inclusive.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                tbInput.Text = ""

                'Input must be in range
            ElseIf (userInput < min Or userInput > max) Then

                MessageBox.Show("Not in range. Please enter a whole number between 0 and 1000, inclusive.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                tbInput.Text = ""

            Else

                unitsShipped(currentEmployee - 1, currentDay - 1) = userInput


                'Outputs input for each day and keeps tracks of the running total for each employee
                If currentEmployee = 1 Then
                    tbEmployee1.Text += "Day " + currentDay.ToString + ": " + unitsShipped(0, currentDay - 1).ToString + vbCrLf
                    tbInput.Text = ""
                    employee1Average += userInput
                ElseIf currentEmployee = 2 Then
                    tbEmployee2.Text += "Day " + currentDay.ToString + ": " + unitsShipped(1, currentDay - 1).ToString + vbCrLf
                    tbInput.Text = ""
                    employee2Average += userInput
                Else
                    tbEmployee3.Text += "Day " + currentDay.ToString + ": " + unitsShipped(2, currentDay - 1).ToString + vbCrLf
                    tbInput.Text = ""
                    employee3Average += userInput
                End If

                'Displays average for each employee when all 7 days are entered
                If currentDay = 7 Then
                    currentDay = 1

                    If (currentEmployee = 1) Then
                        totalAverage += employee1Average
                        employee1Average = employee1Average / 7
                        employee1Average = Math.Round(employee1Average, 2, MidpointRounding.AwayFromZero)
                        lblEmployee1Average.Text = "Average: " + employee1Average.ToString

                        lblEmployee1.Font = New Font(lblEmployee1.Font, FontStyle.Regular)
                        lblEmployee2.Font = New Font(lblEmployee2.Font, FontStyle.Bold)

                    ElseIf (currentEmployee = 2) Then

                        lblEmployee2.Font = New Font(lblEmployee2.Font, FontStyle.Regular)
                        lblEmployee3.Font = New Font(lblEmployee3.Font, FontStyle.Bold)

                        totalAverage += employee2Average
                        employee2Average = employee2Average / 7
                        employee2Average = Math.Round(employee2Average, 2, MidpointRounding.AwayFromZero)
                        lblEmployee2Average.Text = "Average: " + employee2Average.ToString
                    Else
                        totalAverage += employee3Average
                        employee3Average = employee3Average / 7
                        employee3Average = Math.Round(employee3Average, 2, MidpointRounding.AwayFromZero)
                        lblEmployee3Average.Text = "Average: " + employee3Average.ToString
                    End If

                    currentEmployee += 1

                Else
                    currentDay += 1
                End If

                'All employees are fully entered, display total average, restrict form usage
                If currentEmployee > 3 Then
                    btnEnter.Enabled = False
                    tbInput.Enabled = False

                    lblEmployee3.Font = New Font(lblEmployee3.Font, FontStyle.Regular)

                    totalAverage = totalAverage / 21
                    totalAverage = Math.Round(totalAverage, 2, MidpointRounding.AwayFromZero)
                    tbTotalAverage.Text = "Total Average (all 3 employees): " + totalAverage.ToString

                Else

                    lblDay.Text = "Day " + currentDay.ToString

                End If
            End If
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub

    'Resets everything in the form, clears all variables, and resets focus to input box
    Private Sub Clear()
        currentEmployee = 1
        currentDay = 1
        Array.Clear(unitsShipped, 0, unitsShipped.Length)

        lblEmployee2.Font = New Font(lblEmployee2.Font, FontStyle.Bold)

        btnEnter.Enabled = True

        employee1Average = 0
        employee2Average = 0
        employee3Average = 0
        totalAverage = 0

        tbInput.Text = ""
        tbInput.Enabled = True
        tbEmployee1.Text = ""
        tbEmployee2.Text = ""
        tbEmployee3.Text = ""

        lblEmployee1Average.Text = ""
        lblEmployee2Average.Text = ""
        lblEmployee3Average.Text = ""
        tbTotalAverage.Text = ""

        tbInput.Focus()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Clear()
    End Sub
End Class