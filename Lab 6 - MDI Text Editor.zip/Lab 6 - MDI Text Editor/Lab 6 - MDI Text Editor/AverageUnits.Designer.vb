﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AverageUnits
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblUnits = New System.Windows.Forms.Label()
        Me.tbInput = New System.Windows.Forms.TextBox()
        Me.lblEmployee1 = New System.Windows.Forms.Label()
        Me.lblEmployee2 = New System.Windows.Forms.Label()
        Me.lblEmployee3 = New System.Windows.Forms.Label()
        Me.tbEmployee1 = New System.Windows.Forms.TextBox()
        Me.tbEmployee2 = New System.Windows.Forms.TextBox()
        Me.tbEmployee3 = New System.Windows.Forms.TextBox()
        Me.lblEmployee1Average = New System.Windows.Forms.Label()
        Me.lblEmployee2Average = New System.Windows.Forms.Label()
        Me.lblEmployee3Average = New System.Windows.Forms.Label()
        Me.tbTotalAverage = New System.Windows.Forms.TextBox()
        Me.lblDay = New System.Windows.Forms.Label()
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 5
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2.5!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.65!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.65!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.7!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2.5!))
        Me.TableLayoutPanel1.Controls.Add(Me.btnEnter, 1, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.btnReset, 2, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.btnExit, 3, 8)
        Me.TableLayoutPanel1.Controls.Add(Me.lblUnits, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.tbInput, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.lblEmployee1, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.lblEmployee2, 2, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.lblEmployee3, 3, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.tbEmployee1, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.tbEmployee2, 2, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.tbEmployee3, 3, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.lblEmployee1Average, 1, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.lblEmployee2Average, 2, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.lblEmployee3Average, 3, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.tbTotalAverage, 1, 7)
        Me.TableLayoutPanel1.Controls.Add(Me.lblDay, 1, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 10
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.5!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.5!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.24409!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.677166!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.5!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.5!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(683, 508)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'btnEnter
        '
        Me.btnEnter.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnEnter.Location = New System.Drawing.Point(20, 458)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(210, 32)
        Me.btnEnter.TabIndex = 13
        Me.btnEnter.Text = "&Enter"
        Me.ToolTip.SetToolTip(Me.btnEnter, "Press 'Enter' key or click to submit units shipped")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnReset.Location = New System.Drawing.Point(236, 458)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(210, 32)
        Me.btnReset.TabIndex = 14
        Me.btnReset.Text = "&Reset"
        Me.ToolTip.SetToolTip(Me.btnReset, "Press 'Escape' key or click to reset units shipped for every employee")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnExit.Enabled = False
        Me.btnExit.Location = New System.Drawing.Point(452, 458)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(210, 32)
        Me.btnExit.TabIndex = 15
        Me.btnExit.Text = "E&xit"
        Me.ToolTip.SetToolTip(Me.btnExit, "Click to exit the form")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblUnits
        '
        Me.lblUnits.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lblUnits.Location = New System.Drawing.Point(186, 60)
        Me.lblUnits.Name = "lblUnits"
        Me.lblUnits.Size = New System.Drawing.Size(44, 17)
        Me.lblUnits.TabIndex = 1
        Me.lblUnits.Text = "&Units:"
        '
        'tbInput
        '
        Me.tbInput.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.tbInput.Location = New System.Drawing.Point(236, 58)
        Me.tbInput.Name = "tbInput"
        Me.tbInput.Size = New System.Drawing.Size(134, 22)
        Me.tbInput.TabIndex = 2
        Me.ToolTip.SetToolTip(Me.tbInput, "Please enter # of units shipped")
        '
        'lblEmployee1
        '
        Me.lblEmployee1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblEmployee1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmployee1.Location = New System.Drawing.Point(70, 110)
        Me.lblEmployee1.Name = "lblEmployee1"
        Me.lblEmployee1.Size = New System.Drawing.Size(109, 17)
        Me.lblEmployee1.TabIndex = 3
        Me.lblEmployee1.Text = "Employee 1"
        Me.ToolTip.SetToolTip(Me.lblEmployee1, "First employee")
        '
        'lblEmployee2
        '
        Me.lblEmployee2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblEmployee2.Location = New System.Drawing.Point(292, 110)
        Me.lblEmployee2.Name = "lblEmployee2"
        Me.lblEmployee2.Size = New System.Drawing.Size(98, 17)
        Me.lblEmployee2.TabIndex = 4
        Me.lblEmployee2.Text = "Employee 2"
        Me.ToolTip.SetToolTip(Me.lblEmployee2, "Second employee")
        '
        'lblEmployee3
        '
        Me.lblEmployee3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblEmployee3.Location = New System.Drawing.Point(504, 110)
        Me.lblEmployee3.Name = "lblEmployee3"
        Me.lblEmployee3.Size = New System.Drawing.Size(105, 17)
        Me.lblEmployee3.TabIndex = 5
        Me.lblEmployee3.Text = "Employee 3"
        Me.ToolTip.SetToolTip(Me.lblEmployee3, "Third employee")
        '
        'tbEmployee1
        '
        Me.tbEmployee1.BackColor = System.Drawing.Color.White
        Me.tbEmployee1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tbEmployee1.Enabled = False
        Me.tbEmployee1.ForeColor = System.Drawing.Color.Black
        Me.tbEmployee1.Location = New System.Drawing.Point(20, 141)
        Me.tbEmployee1.Multiline = True
        Me.tbEmployee1.Name = "tbEmployee1"
        Me.tbEmployee1.Size = New System.Drawing.Size(210, 234)
        Me.tbEmployee1.TabIndex = 6
        Me.tbEmployee1.TabStop = False
        Me.ToolTip.SetToolTip(Me.tbEmployee1, "Units shipped per day")
        '
        'tbEmployee2
        '
        Me.tbEmployee2.BackColor = System.Drawing.Color.White
        Me.tbEmployee2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tbEmployee2.Enabled = False
        Me.tbEmployee2.ForeColor = System.Drawing.Color.Black
        Me.tbEmployee2.Location = New System.Drawing.Point(236, 141)
        Me.tbEmployee2.Multiline = True
        Me.tbEmployee2.Name = "tbEmployee2"
        Me.tbEmployee2.Size = New System.Drawing.Size(210, 234)
        Me.tbEmployee2.TabIndex = 7
        Me.tbEmployee2.TabStop = False
        Me.ToolTip.SetToolTip(Me.tbEmployee2, "Units shipped per day")
        '
        'tbEmployee3
        '
        Me.tbEmployee3.BackColor = System.Drawing.Color.White
        Me.tbEmployee3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tbEmployee3.Enabled = False
        Me.tbEmployee3.ForeColor = System.Drawing.Color.Black
        Me.tbEmployee3.Location = New System.Drawing.Point(452, 141)
        Me.tbEmployee3.Multiline = True
        Me.tbEmployee3.Name = "tbEmployee3"
        Me.tbEmployee3.Size = New System.Drawing.Size(210, 234)
        Me.tbEmployee3.TabIndex = 8
        Me.tbEmployee3.TabStop = False
        Me.ToolTip.SetToolTip(Me.tbEmployee3, "Units shipped per day")
        '
        'lblEmployee1Average
        '
        Me.lblEmployee1Average.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee1Average.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblEmployee1Average.Location = New System.Drawing.Point(20, 378)
        Me.lblEmployee1Average.Name = "lblEmployee1Average"
        Me.lblEmployee1Average.Size = New System.Drawing.Size(210, 39)
        Me.lblEmployee1Average.TabIndex = 9
        Me.lblEmployee1Average.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip.SetToolTip(Me.lblEmployee1Average, "Employee 1 Average")
        '
        'lblEmployee2Average
        '
        Me.lblEmployee2Average.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee2Average.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblEmployee2Average.Location = New System.Drawing.Point(236, 378)
        Me.lblEmployee2Average.Name = "lblEmployee2Average"
        Me.lblEmployee2Average.Size = New System.Drawing.Size(210, 39)
        Me.lblEmployee2Average.TabIndex = 10
        Me.lblEmployee2Average.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip.SetToolTip(Me.lblEmployee2Average, "Employee 2 Average")
        '
        'lblEmployee3Average
        '
        Me.lblEmployee3Average.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee3Average.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblEmployee3Average.Location = New System.Drawing.Point(452, 378)
        Me.lblEmployee3Average.Name = "lblEmployee3Average"
        Me.lblEmployee3Average.Size = New System.Drawing.Size(210, 39)
        Me.lblEmployee3Average.TabIndex = 11
        Me.lblEmployee3Average.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip.SetToolTip(Me.lblEmployee3Average, "Employee 3 Average")
        '
        'tbTotalAverage
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.tbTotalAverage, 3)
        Me.tbTotalAverage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tbTotalAverage.Location = New System.Drawing.Point(20, 420)
        Me.tbTotalAverage.Multiline = True
        Me.tbTotalAverage.Name = "tbTotalAverage"
        Me.tbTotalAverage.ReadOnly = True
        Me.tbTotalAverage.Size = New System.Drawing.Size(642, 32)
        Me.tbTotalAverage.TabIndex = 12
        Me.tbTotalAverage.TabStop = False
        Me.tbTotalAverage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.ToolTip.SetToolTip(Me.tbTotalAverage, "Total average for all 3 employees")
        '
        'lblDay
        '
        Me.lblDay.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.lblDay.Location = New System.Drawing.Point(185, 22)
        Me.lblDay.Name = "lblDay"
        Me.lblDay.Size = New System.Drawing.Size(45, 17)
        Me.lblDay.TabIndex = 0
        Me.lblDay.Text = "&Day 1"
        Me.ToolTip.SetToolTip(Me.lblDay, "Day of the week")
        '
        'ToolTip
        '
        Me.ToolTip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        '
        'AverageUnits
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(683, 508)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(701, 555)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(701, 555)
        Me.Name = "AverageUnits"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Average Units Shipped By Employee - Jesse Revell"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblDay As Label
    Friend WithEvents lblUnits As Label
    Friend WithEvents tbInput As TextBox
    Friend WithEvents lblEmployee1 As Label
    Friend WithEvents lblEmployee2 As Label
    Friend WithEvents lblEmployee3 As Label
    Friend WithEvents tbEmployee1 As TextBox
    Friend WithEvents tbEmployee2 As TextBox
    Friend WithEvents tbEmployee3 As TextBox
    Friend WithEvents lblEmployee1Average As Label
    Friend WithEvents lblEmployee2Average As Label
    Friend WithEvents lblEmployee3Average As Label
    Friend WithEvents tbTotalAverage As TextBox
    Friend WithEvents ToolTip As ToolTip
End Class
